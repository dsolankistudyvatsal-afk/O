# Verdant Luxe — Express + MongoDB

Pure-vegetarian fine-dining site. The frontend (plain HTML/CSS/JS) now talks to a real
REST API backed by **MongoDB** instead of browser `localStorage`.

## Run it

```bash
npm install
cp .env.example .env        # then edit MONGODB_URI, STAFF_PASSWORD, JWT_SECRET
npm start                   # http://localhost:3000
```

You need MongoDB running locally (`mongodb://127.0.0.1:27017`) **or** a free
[MongoDB Atlas](https://www.mongodb.com/atlas) connection string in `MONGODB_URI`.

On first start the collections are filled with the same sample data the old version had
(12 dishes, 9 tables, 2 orders, 1 reservation, 2 reviews). Manual control:

```bash
npm run seed          # fill only empty collections
npm run seed:reset    # wipe everything and re-seed
```

Staff portal: footer → *Staff login* → password from `STAFF_PASSWORD` (default `admin123`).

Customer accounts: **Sign in** in the navbar → *Create account*. Signed-in guests get their
name/email pre-filled, and their orders and reservations appear under **My account**.
Guests can still order and book without an account.

## Structure

```
public/            frontend (index.html, css/, js/) — served by Express
  js/api.js        fetch client — replaces the old localStorage layer
server/
  index.js         Express app, static hosting, error handler
  config/db.js     Mongoose connection
  models/          MenuItem, DiningTable, Order, Reservation, Review, User, Counter
  routes/          auth, menu, orders, tables, reservations, reviews, stats
  middleware/      JWT staff auth, helpers
  seed/            starter data + seed script
```

## API

| Method | Endpoint | Access | Replaces |
|---|---|---|---|
| POST | `/api/auth/login` | public | hard-coded staff password check |
| POST | `/api/auth/register` | public | — (new) customer sign-up |
| POST | `/api/auth/user-login` | public | — (new) customer sign-in |
| GET | `/api/auth/me` | customer | — (new) |
| GET | `/api/orders/mine` | customer | — (new) order history |
| GET | `/api/reservations/mine` | customer | — (new) reservation history |
| GET | `/api/menu?category=&q=` | public | `getMenuItems` |
| POST | `/api/menu` | staff | `addMenuItem` |
| DELETE | `/api/menu/:id` | staff | `deleteMenuItem` |
| GET | `/api/orders` | staff | `getOrders` |
| POST | `/api/orders` | public | `createOrder` |
| PATCH | `/api/orders/:id/status` | staff | `updateOrderStatus` |
| GET | `/api/tables` | public | `getTables` |
| GET | `/api/reservations` | staff | `getReservations` |
| POST | `/api/reservations` | public | `createReservation` |
| GET / POST | `/api/reviews` | public | `getReviews` / `addReview` |
| GET | `/api/admin/stats` | staff | `getAdminStats` |

Protected endpoints need `Authorization: Bearer <token>`. Staff tokens (from `/api/auth/login`)
last 8 h; customer tokens (from `register` / `user-login`) last 30 days. The two token types
are not interchangeable. `POST /api/orders` and `POST /api/reservations` accept an optional
customer token to link the record to the account.

Passwords are hashed with scrypt (Node's built-in `crypto`, no extra dependency) and never
returned by the API. Min length 8. Login/register are rate-limited per IP.

## Behaviour changes worth knowing

- **Orders are priced on the server.** The client sends item ids + quantities (and a promo
  code); prices, discount and total come from MongoDB, so they can't be tampered with.
- **Staff-only data is protected:** orders/KDS, reservations (guest emails/phones) and stats
  require a staff token. Customers can still place orders and book tables.
- **Double-booking is blocked:** a confirmed reservation for the same table, date and time
  returns a 409 and the toast shows the reason.
- Order / reservation IDs are sequential and collision-free (`ORD-1003`, `RES-8042`, …)
  via an atomic counter collection, instead of random 4-digit numbers.
- Dishes added from the admin panel keep the dietary tags the form sends (`100% Veg`)
  rather than always being tagged *Vegan*.
- Revenue in the dashboard excludes cancelled orders.
- The old `sql/` folder was removed since MongoDB replaces it.

## Deploying

Set `NODE_ENV=production`, a strong `JWT_SECRET` and `STAFF_PASSWORD`, and use an Atlas
`MONGODB_URI`. If you host the frontend on a different origin, set `CORS_ORIGIN` and
`window.API_BASE = 'https://your-api/api'` before `js/api.js` loads.
