const jwt = require('jsonwebtoken');

const DEV_SECRET = 'dev-only-secret-change-me';

function secret() {
  return process.env.JWT_SECRET || DEV_SECRET;
}

function bearer(req) {
  const header = req.headers.authorization || '';
  return header.startsWith('Bearer ') ? header.slice(7) : null;
}

// ---- Staff (admin dashboard + KDS) ----
function signStaffToken() {
  return jwt.sign({ role: 'staff' }, secret(), { expiresIn: '8h' });
}

function requireStaff(req, res, next) {
  const token = bearer(req);
  if (!token) return res.status(401).json({ error: 'Staff login required' });
  try {
    const payload = jwt.verify(token, secret());
    if (payload.role !== 'staff') throw new Error('bad role');
    req.staff = payload;
    next();
  } catch (e) {
    res.status(401).json({ error: 'Session expired or invalid' });
  }
}

// ---- Customers ----
function signUserToken(user) {
  return jwt.sign({ role: 'customer', sub: String(user._id) }, secret(), { expiresIn: '30d' });
}

function readUser(token) {
  try {
    const payload = jwt.verify(token, secret());
    return payload.role === 'customer' && payload.sub ? payload : null;
  } catch (e) {
    return null;
  }
}

/** Attaches req.user when a valid customer token is sent; otherwise continues as guest. */
function optionalUser(req, res, next) {
  const token = bearer(req);
  req.user = token ? readUser(token) : null;
  next();
}

function requireUser(req, res, next) {
  const token = bearer(req);
  const user = token ? readUser(token) : null;
  if (!user) return res.status(401).json({ error: 'Please sign in' });
  req.user = user;
  next();
}

module.exports = { signStaffToken, requireStaff, signUserToken, optionalUser, requireUser, DEV_SECRET };
