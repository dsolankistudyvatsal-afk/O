// Wrap async route handlers so rejected promises reach the error handler
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const str = (v, max = 500) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

// Tiny in-memory brute-force guard (per IP, per route instance)
function rateLimit(max = 8, windowMs = 60_000) {
  const hits = new Map();
  return (req, res, next) => {
    const now = Date.now();
    const recent = (hits.get(req.ip) || []).filter((t) => now - t < windowMs);
    recent.push(now);
    hits.set(req.ip, recent);
    if (recent.length > max) {
      return res.status(429).json({ error: 'Too many attempts. Try again in a minute.' });
    }
    next();
  };
}

module.exports = { wrap, HttpError, escapeRegex, str, rateLimit };
