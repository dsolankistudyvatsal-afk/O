const express = require('express');
const DiningTable = require('../models/DiningTable');
const { wrap } = require('../middleware/helpers');

const router = express.Router();

// GET /api/tables
router.get('/', wrap(async (req, res) => {
  const tables = await DiningTable.find().sort({ id: 1 });
  // natural order T1, T2, ... T10
  tables.sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));
  res.json(tables);
}));

module.exports = router;
