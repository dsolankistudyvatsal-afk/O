const express = require('express');
const MenuItem = require('../models/MenuItem');
const { requireStaff } = require('../middleware/auth');
const { wrap, HttpError, escapeRegex, str } = require('../middleware/helpers');

const router = express.Router();

// GET /api/menu?category=mains&q=truffle
router.get('/', wrap(async (req, res) => {
  const filter = {};
  const { category, q } = req.query;
  if (category && category !== 'all') filter.category = String(category);
  if (q) {
    const rx = new RegExp(escapeRegex(String(q).slice(0, 100)), 'i');
    filter.$or = [{ name: rx }, { description: rx }];
  }
  const items = await MenuItem.find(filter).sort({ createdAt: 1, _id: 1 });
  res.json(items);
}));

// POST /api/menu  (staff)
router.post('/', requireStaff, wrap(async (req, res) => {
  const b = req.body || {};
  const price = Number(b.price);
  const calories = Number(b.calories) || 0;
  const name = str(b.name, 160);
  const description = str(b.description, 1000);

  if (!name || !description) throw new HttpError(400, 'Name and description are required');
  if (!MenuItem.CATEGORIES.includes(b.category)) throw new HttpError(400, 'Invalid category');
  if (!Number.isFinite(price) || price <= 0) throw new HttpError(400, 'Price must be a positive number');

  const dietary = Array.isArray(b.dietary) && b.dietary.length
    ? b.dietary.map((d) => str(d, 40)).filter(Boolean)
    : ['100% Veg'];

  const item = await MenuItem.create({
    id: 'm_' + Date.now() + Math.floor(Math.random() * 100),
    name,
    category: b.category,
    price,
    calories,
    description,
    image: str(b.image, 500),
    dietary,
    featured: !!b.featured,
    available: true
  });
  res.status(201).json(item);
}));

// DELETE /api/menu/:id  (staff)
router.delete('/:id', requireStaff, wrap(async (req, res) => {
  const result = await MenuItem.deleteOne({ id: req.params.id });
  if (!result.deletedCount) throw new HttpError(404, 'Dish not found');
  res.json({ success: true });
}));

module.exports = router;
