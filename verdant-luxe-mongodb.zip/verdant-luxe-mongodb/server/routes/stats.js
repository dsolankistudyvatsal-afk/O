const express = require('express');
const Order = require('../models/Order');
const Reservation = require('../models/Reservation');
const DiningTable = require('../models/DiningTable');
const { requireStaff } = require('../middleware/auth');
const { wrap } = require('../middleware/helpers');

const router = express.Router();

// GET /api/admin/stats  (staff)
router.get('/stats', requireStaff, wrap(async (req, res) => {
  const [revAgg, orderCount, reservationCount, tableCount, occupied] = await Promise.all([
    Order.aggregate([
      { $match: { status: { $ne: 'cancelled' } } },
      { $group: { _id: null, revenue: { $sum: '$total' } } }
    ]),
    Order.countDocuments(),
    Reservation.countDocuments(),
    DiningTable.countDocuments(),
    DiningTable.countDocuments({ status: 'occupied' })
  ]);

  const revenue = revAgg.length ? revAgg[0].revenue : 0;
  res.json({
    revenue: revenue.toFixed(2),
    orderCount,
    reservationCount,
    occupancyRate: tableCount ? Math.round((occupied / tableCount) * 100) + '%' : '0%'
  });
}));

module.exports = router;
