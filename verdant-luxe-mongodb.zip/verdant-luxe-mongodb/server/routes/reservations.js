const express = require('express');
const Reservation = require('../models/Reservation');
const DiningTable = require('../models/DiningTable');
const Counter = require('../models/Counter');
const { requireStaff, requireUser, optionalUser } = require('../middleware/auth');
const { wrap, HttpError, str } = require('../middleware/helpers');

const router = express.Router();

const EMAIL_RX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// GET /api/reservations/mine  (signed-in customer)
router.get('/mine', requireUser, wrap(async (req, res) => {
  const list = await Reservation.find({ userId: req.user.sub }).sort({ date: -1, time: -1 }).limit(50);
  res.json(list);
}));

// GET /api/reservations  (staff) — newest first
router.get('/', requireStaff, wrap(async (req, res) => {
  const list = await Reservation.find().sort({ createdAt: -1, _id: -1 });
  res.json(list);
}));

// POST /api/reservations  (guest or signed-in)
router.post('/', optionalUser, wrap(async (req, res) => {
  const b = req.body || {};
  const name = str(b.name, 120);
  const email = str(b.email, 160);
  const phone = str(b.phone, 40);
  const date = str(b.date, 10);
  const time = str(b.time, 5);
  const guests = Number(b.guests);

  if (!name || !phone) throw new HttpError(400, 'Name and phone are required');
  if (!EMAIL_RX.test(email)) throw new HttpError(400, 'A valid email is required');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(date))) throw new HttpError(400, 'Invalid date');
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new HttpError(400, 'Invalid time');
  if (!Number.isInteger(guests) || guests < 1 || guests > 20) throw new HttpError(400, 'Guests must be between 1 and 20');

  let tableId = str(b.tableId, 10) || null;
  let zone = str(b.zone, 80);
  if (tableId) {
    const table = await DiningTable.findOne({ id: tableId });
    if (!table) throw new HttpError(400, 'Unknown table');
    zone = table.zone; // trust the database, not the client

    const clash = await Reservation.exists({ tableId, date, time, status: 'confirmed' });
    if (clash) throw new HttpError(409, `Table ${tableId} is already booked for that time`);
  }

  const seq = await Counter.next('reservations');
  const reservation = await Reservation.create({
    id: 'RES-' + (8000 + seq),
    name, email, phone, date, time, guests, tableId, zone,
    specialNotes: str(b.specialNotes, 500),
    userId: req.user ? req.user.sub : null,
    status: 'confirmed'
  });
  res.status(201).json(reservation);
}));

module.exports = router;
