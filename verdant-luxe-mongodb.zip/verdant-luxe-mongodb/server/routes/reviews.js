const express = require('express');
const Review = require('../models/Review');
const { wrap, HttpError, str } = require('../middleware/helpers');

const router = express.Router();

// GET /api/reviews — newest first
router.get('/', wrap(async (req, res) => {
  const reviews = await Review.find().sort({ date: -1, createdAt: -1 });
  res.json(reviews);
}));

// POST /api/reviews  (public)  { author, rating, comment }
router.post('/', wrap(async (req, res) => {
  const b = req.body || {};
  const author = str(b.author, 80);
  const comment = str(b.comment, 1000);
  const rating = Number(b.rating);

  if (!author || !comment) throw new HttpError(400, 'Name and comment are required');
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new HttpError(400, 'Rating must be 1–5');

  const review = await Review.create({
    id: 'rev_' + Date.now() + Math.floor(Math.random() * 100),
    author, rating, comment,
    date: new Date().toISOString().split('T')[0]
  });
  res.status(201).json(review);
}));

module.exports = router;
