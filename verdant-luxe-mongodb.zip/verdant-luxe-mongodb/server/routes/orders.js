const express = require('express');
const Order = require('../models/Order');
const MenuItem = require('../models/MenuItem');
const Counter = require('../models/Counter');
const { requireStaff, requireUser, optionalUser } = require('../middleware/auth');
const { wrap, HttpError, str } = require('../middleware/helpers');

const router = express.Router();

// Same codes the frontend accepts (js/cart.js) — now validated on the server
const PROMO_CODES = { AURAGOLD: 15, VERDANT15: 15 };
const STATUSES = ['new', 'prep', 'ready', 'done', 'cancelled'];

// GET /api/orders/mine  (signed-in customer) — their own order history
router.get('/mine', requireUser, wrap(async (req, res) => {
  const orders = await Order.find({ userId: req.user.sub }).sort({ timestamp: -1 }).limit(50);
  res.json(orders);
}));

// GET /api/orders  (staff / KDS) — newest first
router.get('/', requireStaff, wrap(async (req, res) => {
  const orders = await Order.find().sort({ timestamp: -1 }).limit(200);
  res.json(orders);
}));

// POST /api/orders  (guest or signed-in checkout)
// Body: { customerName, type, items: [{ id, qty }], promoCode? }
// Prices and total are computed from the database — client values are ignored.
router.post('/', optionalUser, wrap(async (req, res) => {
  const b = req.body || {};
  const rawItems = Array.isArray(b.items) ? b.items : [];
  if (!rawItems.length) throw new HttpError(400, 'Order has no items');
  if (rawItems.length > 50) throw new HttpError(400, 'Too many line items');

  // merge duplicate ids and validate quantities
  const qtyById = new Map();
  for (const it of rawItems) {
    const qty = Number(it && it.qty);
    if (!it || typeof it.id !== 'string' || !Number.isInteger(qty) || qty < 1 || qty > 50) {
      throw new HttpError(400, 'Invalid order item');
    }
    qtyById.set(it.id, (qtyById.get(it.id) || 0) + qty);
  }

  const dishes = await MenuItem.find({ id: { $in: [...qtyById.keys()] } });
  const byId = new Map(dishes.map((d) => [d.id, d]));

  const items = [];
  let subtotal = 0;
  for (const [id, qty] of qtyById) {
    const dish = byId.get(id);
    if (!dish || !dish.available) throw new HttpError(400, `Dish no longer available: ${id}`);
    items.push({ id: dish.id, name: dish.name, qty, price: dish.price });
    subtotal += dish.price * qty;
  }

  const code = str(b.promoCode, 40).toUpperCase();
  const pct = PROMO_CODES[code] || 0;
  const total = Math.round(subtotal * (100 - pct)) / 100;

  const seq = await Counter.next('orders');
  const order = await Order.create({
    id: 'ORD-' + (1000 + seq),
    customerName: str(b.customerName, 120) || 'Valued Guest',
    type: str(b.type, 60) || 'Dine-In',
    items,
    status: 'new',
    total,
    promoCode: pct ? code : '',
    userId: req.user ? req.user.sub : null,
    timestamp: Date.now()
  });
  res.status(201).json(order);
}));

// PATCH /api/orders/:id/status  (staff)  { status }
router.patch('/:id/status', requireStaff, wrap(async (req, res) => {
  const status = req.body && req.body.status;
  if (!STATUSES.includes(status)) throw new HttpError(400, 'Invalid status');
  const order = await Order.findOneAndUpdate({ id: req.params.id }, { status }, { new: true });
  if (!order) throw new HttpError(404, 'Order not found');
  res.json(order);
}));

module.exports = router;
