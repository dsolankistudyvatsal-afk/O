const express = require('express');
const crypto = require('crypto');
const User = require('../models/User');
const { signStaffToken, signUserToken, requireUser } = require('../middleware/auth');
const { hashPassword, verifyPassword } = require('../middleware/password');
const { wrap, HttpError, str, rateLimit } = require('../middleware/helpers');

const router = express.Router();
const EMAIL_RX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

// ---------------- Staff ----------------
// POST /api/auth/login  { password }
router.post('/login', rateLimit(8), (req, res, next) => {
  try {
    const expected = process.env.STAFF_PASSWORD || 'admin123';
    if (!safeEqual(req.body && req.body.password, expected)) {
      throw new HttpError(401, 'Incorrect password');
    }
    res.json({ token: signStaffToken() });
  } catch (e) {
    next(e);
  }
});

// ---------------- Customers ----------------
// POST /api/auth/register  { name, email, password }
router.post('/register', rateLimit(10), wrap(async (req, res) => {
  const b = req.body || {};
  const name = str(b.name, 80);
  const email = str(b.email, 160).toLowerCase();
  const password = typeof b.password === 'string' ? b.password : '';

  if (!name) throw new HttpError(400, 'Name is required');
  if (!EMAIL_RX.test(email)) throw new HttpError(400, 'A valid email is required');
  if (password.length < 8 || password.length > 128) {
    throw new HttpError(400, 'Password must be 8–128 characters');
  }
  if (await User.exists({ email })) {
    throw new HttpError(409, 'An account with this email already exists');
  }

  const user = await User.create({ name, email, passwordHash: await hashPassword(password) });
  res.status(201).json({ token: signUserToken(user), user });
}));

// POST /api/auth/user-login  { email, password }
router.post('/user-login', rateLimit(8), wrap(async (req, res) => {
  const b = req.body || {};
  const email = str(b.email, 160).toLowerCase();
  const password = typeof b.password === 'string' ? b.password : '';

  const user = email ? await User.findOne({ email }) : null;
  const ok = user ? await verifyPassword(password, user.passwordHash) : false;
  if (!ok) throw new HttpError(401, 'Incorrect email or password');

  res.json({ token: signUserToken(user), user });
}));

// GET /api/auth/me  (customer)
router.get('/me', requireUser, wrap(async (req, res) => {
  const user = await User.findById(req.user.sub);
  if (!user) throw new HttpError(401, 'Account no longer exists');
  res.json(user);
}));

module.exports = router;
