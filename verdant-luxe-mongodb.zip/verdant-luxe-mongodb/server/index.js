require('dotenv').config();
const path = require('path');
const express = require('express');
const mongoose = require('mongoose');

const connectDB = require('./config/db');
const seed = require('./seed/seed');

const app = express();
app.disable('x-powered-by');

if (process.env.CORS_ORIGIN) {
  app.use(require('cors')({ origin: process.env.CORS_ORIGIN.split(',') }));
}
app.use(express.json({ limit: '100kb' }));

// ---- API ----
app.get('/api/health', (req, res) => {
  res.json({ ok: true, db: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' });
});
app.use('/api/auth', require('./routes/auth'));
app.use('/api/menu', require('./routes/menu'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/tables', require('./routes/tables'));
app.use('/api/reservations', require('./routes/reservations'));
app.use('/api/reviews', require('./routes/reviews'));
app.use('/api/admin', require('./routes/stats'));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

// ---- Frontend (only /public is exposed) ----
app.use(express.static(path.join(__dirname, '..', 'public')));

// ---- Errors ----
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' });
  if (err.name === 'ValidationError') return res.status(400).json({ error: err.message });
  if (err.code === 11000) return res.status(409).json({ error: 'Duplicate record' });
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? 'Server error' : err.message });
});

async function start() {
  if (!process.env.JWT_SECRET) {
    console.warn('⚠  JWT_SECRET not set — using an insecure dev secret. Set it in .env.');
    if (process.env.NODE_ENV === 'production') process.exit(1);
  }
  if (!process.env.STAFF_PASSWORD) console.warn('⚠  STAFF_PASSWORD not set — defaulting to "admin123".');

  await connectDB();
  if (process.env.AUTO_SEED !== 'false') await seed();

  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`Verdant Luxe running at http://localhost:${port}`));
}

start().catch((err) => {
  console.error('Failed to start:', err.message);
  process.exit(1);
});
