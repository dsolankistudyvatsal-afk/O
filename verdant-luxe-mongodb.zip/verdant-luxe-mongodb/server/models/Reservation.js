const mongoose = require('mongoose');
const cleanJSON = require('./cleanJSON');

const reservationSchema = new mongoose.Schema(
  {
    id: { type: String, required: true, unique: true }, // RES-8042
    name: { type: String, required: true, trim: true, maxlength: 120 },
    email: { type: String, required: true, trim: true, lowercase: true, maxlength: 160 },
    phone: { type: String, required: true, trim: true, maxlength: 40 },
    date: { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ }, // YYYY-MM-DD
    time: { type: String, required: true, match: /^\d{2}:\d{2}$/ },       // HH:MM
    guests: { type: Number, required: true, min: 1, max: 20 },
    tableId: { type: String, default: null },
    zone: { type: String, default: '' },
    specialNotes: { type: String, default: '', maxlength: 500 },
    userId: { type: String, default: null, index: true }, // set when a signed-in customer booked
    status: { type: String, enum: ['confirmed', 'cancelled', 'completed', 'no_show'], default: 'confirmed' }
  },
  { timestamps: true }
);

reservationSchema.index({ date: 1, time: 1, tableId: 1 });
cleanJSON(reservationSchema, (ret) => { delete ret.userId; });
module.exports = mongoose.model('Reservation', reservationSchema);
