// Keeps API responses identical in shape to the old localStorage objects:
// no _id / __v / createdAt / updatedAt noise.
module.exports = function cleanJSON(schema, extra) {
  schema.set('toJSON', {
    virtuals: false,
    versionKey: false,
    transform(doc, ret) {
      delete ret._id;
      delete ret.__v;
      delete ret.createdAt;
      delete ret.updatedAt;
      if (extra) extra(ret);
      return ret;
    }
  });
};
