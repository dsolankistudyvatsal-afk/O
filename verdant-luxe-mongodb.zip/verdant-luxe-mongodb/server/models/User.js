const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: { type: String, required: true, unique: true, trim: true, lowercase: true, maxlength: 160 },
    passwordHash: { type: String, required: true } // "salt:hash" (scrypt) — never sent to the client
  },
  { timestamps: true }
);

// Public shape: never expose the hash
userSchema.set('toJSON', {
  transform: (doc, ret) => ({ id: String(ret._id), name: ret.name, email: ret.email })
});

module.exports = mongoose.model('User', userSchema);
