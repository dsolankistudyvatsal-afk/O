const mongoose = require('mongoose');
const cleanJSON = require('./cleanJSON');

const CATEGORIES = ['specials', 'appetizers', 'mains', 'desserts', 'cocktails'];

const menuItemSchema = new mongoose.Schema(
  {
    id: { type: String, required: true, unique: true, trim: true },
    name: { type: String, required: true, trim: true, maxlength: 160 },
    category: { type: String, required: true, enum: CATEGORIES, index: true },
    price: { type: Number, required: true, min: 0 },
    calories: { type: Number, min: 0, default: 0 },
    description: { type: String, required: true, trim: true, maxlength: 1000 },
    image: { type: String, trim: true, default: '' },
    dietary: { type: [String], default: ['100% Veg'] },
    featured: { type: Boolean, default: false },
    available: { type: Boolean, default: true }
  },
  { timestamps: true }
);

menuItemSchema.index({ name: 'text', description: 'text' });
cleanJSON(menuItemSchema);

module.exports = mongoose.model('MenuItem', menuItemSchema);
module.exports.CATEGORIES = CATEGORIES;
