const mongoose = require('mongoose');
const cleanJSON = require('./cleanJSON');

const diningTableSchema = new mongoose.Schema(
  {
    id: { type: String, required: true, unique: true, trim: true }, // T1..T9
    zone: { type: String, required: true, trim: true },
    capacity: { type: Number, required: true, min: 1 },
    status: { type: String, enum: ['available', 'occupied', 'reserved'], default: 'available' }
  },
  { timestamps: true }
);

cleanJSON(diningTableSchema);
module.exports = mongoose.model('DiningTable', diningTableSchema);
