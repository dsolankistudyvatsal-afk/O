const mongoose = require('mongoose');
const cleanJSON = require('./cleanJSON');

const orderItemSchema = new mongoose.Schema(
  {
    id: { type: String, required: true },      // menu item id
    name: { type: String, required: true },    // snapshot of the dish name
    qty: { type: Number, required: true, min: 1 },
    price: { type: Number, required: true, min: 0 } // snapshot of the unit price
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema(
  {
    id: { type: String, required: true, unique: true }, // ORD-1003
    customerName: { type: String, required: true, trim: true, maxlength: 120 },
    type: { type: String, default: 'Dine-In', trim: true, maxlength: 60 },
    items: { type: [orderItemSchema], validate: (v) => v.length > 0 },
    status: { type: String, enum: ['new', 'prep', 'ready', 'done', 'cancelled'], default: 'new', index: true },
    total: { type: Number, required: true, min: 0 },
    promoCode: { type: String, default: '' },
    userId: { type: String, default: null, index: true }, // set when a signed-in customer ordered
    timestamp: { type: Number, default: () => Date.now(), index: true } // ms since epoch (used by KDS timers)
  },
  { timestamps: true }
);

cleanJSON(orderSchema, (ret) => {
  if (!ret.promoCode) delete ret.promoCode;
  delete ret.userId;
});
module.exports = mongoose.model('Order', orderSchema);
