const mongoose = require('mongoose');
const cleanJSON = require('./cleanJSON');

const reviewSchema = new mongoose.Schema(
  {
    id: { type: String, required: true, unique: true },
    author: { type: String, required: true, trim: true, maxlength: 80 },
    rating: { type: Number, required: true, min: 1, max: 5 },
    comment: { type: String, required: true, trim: true, maxlength: 1000 },
    date: { type: String, required: true } // YYYY-MM-DD
  },
  { timestamps: true }
);

reviewSchema.index({ date: -1, createdAt: -1 });
cleanJSON(reviewSchema);
module.exports = mongoose.model('Review', reviewSchema);
