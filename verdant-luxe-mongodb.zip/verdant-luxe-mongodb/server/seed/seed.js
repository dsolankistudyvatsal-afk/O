/* Seeds MongoDB with the same starter data the localStorage version shipped with.
 *   npm run seed          -> fills only EMPTY collections (safe)
 *   npm run seed:reset    -> wipes everything, then re-seeds
 */
const MenuItem = require('../models/MenuItem');
const DiningTable = require('../models/DiningTable');
const Order = require('../models/Order');
const Reservation = require('../models/Reservation');
const Review = require('../models/Review');
const Counter = require('../models/Counter');
const data = require('./data');

async function seed({ reset = false } = {}) {
  if (reset) {
    await Promise.all([
      MenuItem.deleteMany({}), DiningTable.deleteMany({}), Order.deleteMany({}),
      Reservation.deleteMany({}), Review.deleteMany({}), Counter.deleteMany({})
    ]);
  }

  const plan = [
    [MenuItem, data.menu, 'menu items'],
    [DiningTable, data.tables, 'tables'],
    [Review, data.reviews, 'reviews'],
    [Order, data.buildOrders(), 'orders'],
    [Reservation, data.buildReservations(), 'reservations']
  ];

  for (const [Model, docs, label] of plan) {
    if ((await Model.estimatedDocumentCount()) === 0) {
      await Model.insertMany(docs);
      console.log(`  seeded ${docs.length} ${label}`);
    }
  }

  for (const c of data.counters) {
    await Counter.updateOne({ _id: c._id }, { $setOnInsert: { seq: c.seq } }, { upsert: true });
  }
}

module.exports = seed;

// CLI usage
if (require.main === module) {
  require('dotenv').config();
  const mongoose = require('mongoose');
  const connectDB = require('../config/db');
  connectDB()
    .then(() => seed({ reset: process.argv.includes('--reset') }))
    .then(() => { console.log('Seed complete.'); return mongoose.disconnect(); })
    .catch((err) => { console.error('Seed failed:', err.message); process.exit(1); });
}
