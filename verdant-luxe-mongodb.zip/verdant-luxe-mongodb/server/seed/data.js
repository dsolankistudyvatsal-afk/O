/* Seed data for Verdant Luxe — generated from the original INITIAL_* constants in js/api.js */

const menu = [
  {
    "id": "m1",
    "name": "Truffle Wild Mushroom Risotto",
    "category": "specials",
    "price": 48,
    "calories": 520,
    "description": "Acquerello carnaroli rice with porcini mushrooms, Périgord black truffle emulsion, and aged plant-based parmesan crisp.",
    "image": "https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "GF",
      "Vegan Opt"
    ],
    "featured": true,
    "available": true
  },
  {
    "id": "m2",
    "name": "Roasted Organic Butternut Squash Steak",
    "category": "specials",
    "price": 42,
    "calories": 410,
    "description": "Maple-glazed roasted heirloom butternut squash steak served over smoked parsnip puree and toasted pumpkin seeds.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "Vegan",
      "GF"
    ],
    "featured": true,
    "available": true
  },
  {
    "id": "m3",
    "name": "Golden Périgord Truffle Tagliatelle",
    "category": "mains",
    "price": 45,
    "calories": 560,
    "description": "Handcrafted eggless spinach tagliatelle, velvety cashew truffle cream, and fresh shaved black summer truffles.",
    "image": "https://images.unsplash.com/photo-1621996346565-e3d5d6281270?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "Vegan"
    ],
    "featured": false,
    "available": true
  },
  {
    "id": "m4",
    "name": "Pan-Seared King Oyster Scallops",
    "category": "mains",
    "price": 38,
    "calories": 340,
    "description": "Herb-marinated King Oyster mushroom medallions, sweet pea coulis, braised baby leeks, and saffron dashi foam.",
    "image": "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "Vegan",
      "GF"
    ],
    "featured": false,
    "available": true
  },
  {
    "id": "m5",
    "name": "Heirloom Beetroot & Goat Cheese Carpaccio",
    "category": "appetizers",
    "price": 26,
    "calories": 220,
    "description": "Thinly sliced golden and ruby beetroots, artisan organic goat cheese, candied walnuts, micro arugula, and aged balsamic glaze.",
    "image": "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "GF"
    ],
    "featured": false,
    "available": true
  },
  {
    "id": "m6",
    "name": "Crispy Wild Mushroom Arancini",
    "category": "appetizers",
    "price": 24,
    "calories": 310,
    "description": "Golden fried arborio rice spheres filled with braised wild forest mushrooms and vegan mozzarella, served with truffle aioli.",
    "image": "https://images.unsplash.com/photo-1541529086526-db283c563270?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "Vegan"
    ],
    "featured": false,
    "available": true
  },
  {
    "id": "m7",
    "name": "Smoked Avocado & Plant Caviar Tartare",
    "category": "appetizers",
    "price": 32,
    "calories": 280,
    "description": "Hass avocado tartare infused with citrus oil, black sea kelp vegan caviar, shallot confit, and flaxseed crisp crackers.",
    "image": "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "Vegan",
      "GF"
    ],
    "featured": true,
    "available": true
  },
  {
    "id": "m8",
    "name": "Wood-Fired Roman Artichoke Hearts",
    "category": "appetizers",
    "price": 28,
    "calories": 230,
    "description": "Charred Roman globe artichokes, lemon herb emulsion, toasted pine nuts, and micro basil leaf salad.",
    "image": "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "Vegan",
      "GF"
    ],
    "featured": false,
    "available": true
  },
  {
    "id": "m9",
    "name": "Decadent Plant-Based Chocolate Dome",
    "category": "desserts",
    "price": 22,
    "calories": 460,
    "description": "Valrhona 70% dark vegan chocolate dome filled with hazelnut praline mousse, melted with warm organic coconut caramel drip.",
    "image": "https://images.unsplash.com/photo-1579372786545-d24232daf58c?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "Vegan"
    ],
    "featured": true,
    "available": true
  },
  {
    "id": "m10",
    "name": "Pistachio Vanilla Bean Soufflé",
    "category": "desserts",
    "price": 20,
    "calories": 360,
    "description": "Light organic vanilla bean soufflé paired with house-made Sicilian pistachio gelato.",
    "image": "https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg"
    ],
    "featured": false,
    "available": true
  },
  {
    "id": "m11",
    "name": "Botanical Garden Elixir",
    "category": "cocktails",
    "price": 22,
    "calories": 140,
    "description": "Artisanal gin, muddled English cucumber, elderflower tonic, fresh rosemary smoke, and edible violet flowers.",
    "image": "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "Vegan",
      "GF"
    ],
    "featured": true,
    "available": true
  },
  {
    "id": "m12",
    "name": "Green Emerald Yuzu Tonic",
    "category": "cocktails",
    "price": 18,
    "calories": 120,
    "description": "Fresh ceremonial matcha, yuzu juice, sparkling mineral water, lemongrass syrup, and mint mist.",
    "image": "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80",
    "dietary": [
      "100% Veg",
      "Vegan",
      "GF"
    ],
    "featured": false,
    "available": true
  }
];

const tables = [
  {
    "id": "T1",
    "zone": "Main Botanical Hall",
    "capacity": 2,
    "status": "available"
  },
  {
    "id": "T2",
    "zone": "Main Botanical Hall",
    "capacity": 4,
    "status": "occupied"
  },
  {
    "id": "T3",
    "zone": "Chef Garden Counter",
    "capacity": 2,
    "status": "available"
  },
  {
    "id": "T4",
    "zone": "Chef Garden Counter",
    "capacity": 2,
    "status": "available"
  },
  {
    "id": "T5",
    "zone": "Greenhouse Terrace",
    "capacity": 4,
    "status": "occupied"
  },
  {
    "id": "T6",
    "zone": "Greenhouse Terrace",
    "capacity": 6,
    "status": "available"
  },
  {
    "id": "T7",
    "zone": "VIP Garden Suite",
    "capacity": 8,
    "status": "available"
  },
  {
    "id": "T8",
    "zone": "VIP Garden Suite",
    "capacity": 10,
    "status": "occupied"
  },
  {
    "id": "T9",
    "zone": "Main Botanical Hall",
    "capacity": 2,
    "status": "available"
  }
];

const reviews = [
  {
    "id": "rev1",
    "author": "Chef Ananya Gupta",
    "rating": 5,
    "date": "2026-08-26",
    "comment": "Finally a 100% Pure Vegetarian fine dining restaurant of true Michelin quality! The Truffle Wild Mushroom Risotto is divine."
  },
  {
    "id": "rev2",
    "author": "Julian Thorne",
    "rating": 5,
    "date": "2026-08-24",
    "comment": "The Roasted Butternut Squash Steak and Botanical Cocktail paired perfectly. 10/10 plant-based perfection!"
  }
];

// Time-relative samples (built at seed time, like the originals)
function buildOrders() {
  return [
    {
      id: 'ORD-1001',
      customerName: 'Aria Sharma',
      type: 'Dine-In (Table T2)',
      items: [
        { id: 'm1', name: 'Truffle Wild Mushroom Risotto', qty: 2, price: 48.0 },
        { id: 'm11', name: 'Botanical Garden Elixir', qty: 2, price: 22.0 }
      ],
      status: 'prep',
      total: 140.0,
      timestamp: Date.now() - 15 * 60 * 1000
    },
    {
      id: 'ORD-1002',
      customerName: 'Devin Mehta',
      type: 'Takeout',
      items: [
        { id: 'm2', name: 'Roasted Organic Butternut Squash Steak', qty: 1, price: 42.0 },
        { id: 'm9', name: 'Decadent Plant-Based Chocolate Dome', qty: 1, price: 22.0 }
      ],
      status: 'new',
      total: 64.0,
      timestamp: Date.now() - 5 * 60 * 1000
    }
  ];
}

function buildReservations() {
  return [
    {
      id: 'RES-8041',
      name: 'Priya Sundaram',
      email: 'priya@sundaram.org',
      phone: '+1 (555) 019-2834',
      date: new Date().toISOString().split('T')[0],
      time: '19:30',
      guests: 4,
      tableId: 'T5',
      zone: 'Greenhouse Terrace',
      specialNotes: '100% Pure Vegan Birthday Celebration',
      status: 'confirmed'
    }
  ];
}

// Counters so new IDs continue after the seeded ones: ORD-1003, RES-8042 ...
// (ID = base + seq, see routes/orders.js and routes/reservations.js)
const counters = [
  { _id: 'orders', seq: 2 },
  { _id: 'reservations', seq: 41 }
];

module.exports = { menu, tables, reviews, buildOrders, buildReservations, counters };
