/* ==========================================================================
   VERDANT LUXE - Router, Auth & Client / Staff mode switcher
   ========================================================================== */

const STAFF_VIEWS = new Set(['admin', 'kds']);
const CLIENT_VIEWS = new Set(['home', 'menu', 'reservation', 'reviews', 'account', 'myaccount']);

const Auth = {
  TOKEN_KEY: 'vl_staff_token',

  _token() {
    try { return sessionStorage.getItem(this.TOKEN_KEY); } catch (e) { return null; }
  },

  isStaff() {
    const token = this._token();
    if (!token) return false;
    // Drop tokens that have already expired (server still verifies on every call)
    try {
      const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      if (payload.exp && payload.exp * 1000 < Date.now()) {
        sessionStorage.removeItem(this.TOKEN_KEY);
        return false;
      }
    } catch (e) { /* malformed → let the server reject it */ }
    return true;
  },

  async login(password) {
    try {
      const token = await API.login(password);
      try { sessionStorage.setItem(this.TOKEN_KEY, token); } catch (e) {}
      this.applyChrome();
      return { ok: true };
    } catch (err) {
      return { ok: false, message: err.message };
    }
  },

  /** Called by api.js when the server rejects the staff token */
  expireSession() {
    try { sessionStorage.removeItem(this.TOKEN_KEY); } catch (e) {}
    this.applyChrome();
    if (typeof navigateToView === 'function') navigateToView('login');
    if (window.showToast) window.showToast('Session expired — please sign in again', 'error');
  },

  // ---------------- Customer accounts ----------------
  USER_TOKEN_KEY: 'vl_user_token',
  USER_KEY: 'vl_user',

  _expired(token) {
    try {
      const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      return !!(payload.exp && payload.exp * 1000 < Date.now());
    } catch (e) { return false; } // malformed → let the server decide
  },

  isUser() {
    try {
      const token = localStorage.getItem(this.USER_TOKEN_KEY);
      if (!token) return false;
      if (this._expired(token)) { this._clearUser(); return false; }
      return true;
    } catch (e) { return false; }
  },

  currentUser() {
    if (!this.isUser()) return null;
    try { return JSON.parse(localStorage.getItem(this.USER_KEY)); } catch (e) { return null; }
  },

  _saveUser({ token, user }) {
    try {
      localStorage.setItem(this.USER_TOKEN_KEY, token);
      localStorage.setItem(this.USER_KEY, JSON.stringify(user));
    } catch (e) {}
  },

  _clearUser() {
    try {
      localStorage.removeItem(this.USER_TOKEN_KEY);
      localStorage.removeItem(this.USER_KEY);
    } catch (e) {}
  },

  async userLogin(email, password) {
    try {
      this._saveUser(await API.userLogin(email, password));
      this.applyChrome();
      return { ok: true };
    } catch (err) { return { ok: false, message: err.message }; }
  },

  async register(name, email, password) {
    try {
      this._saveUser(await API.register(name, email, password));
      this.applyChrome();
      return { ok: true };
    } catch (err) { return { ok: false, message: err.message }; }
  },

  userLogout() {
    this.prefillForms(true);
    this._clearUser();
    this.applyChrome();
    if (typeof navigateToView === 'function') navigateToView('home');
    if (window.showToast) window.showToast('Signed out', 'info');
  },

  /** Called by api.js when the server rejects the customer token */
  expireUser() {
    this._clearUser();
    this.applyChrome();
    const onAccount = document.getElementById('view-myaccount');
    if (onAccount && onAccount.classList.contains('active') && typeof navigateToView === 'function') {
      navigateToView('account');
    }
    if (window.showToast) window.showToast('Session expired — please sign in again', 'error');
  },

  /** Fill (or, with clear=true, empty) name/email fields from the signed-in profile */
  prefillForms(clear = false) {
    const user = this.currentUser();
    if (!user) return;
    const map = { 'checkout-name': user.name, 'res-name': user.name, 'res-email': user.email, 'review-author': user.name };
    Object.entries(map).forEach(([id, value]) => {
      const el = document.getElementById(id);
      if (!el) return;
      if (clear) { if (el.value === value) el.value = ''; }
      else if (!el.value) el.value = value;
    });
  },

  logout() {
    try { sessionStorage.removeItem(this.TOKEN_KEY); } catch (e) {}
    this.applyChrome();
    if (typeof navigateToView === 'function') navigateToView('home');
    if (window.showToast) window.showToast('Signed out of staff portal', 'info');
  },

  /** Toggle client vs staff navbar / cart */
  applyChrome() {
    const staff = this.isStaff();
    const navClient = document.getElementById('nav-client');
    const navStaff = document.getElementById('nav-staff');
    const actionsClient = document.getElementById('nav-actions-client');
    const actionsStaff = document.getElementById('nav-actions-staff');
    const footerLink = document.getElementById('footer-staff-link');
    const navbar = document.getElementById('main-navbar');
    const cartOverlay = document.getElementById('cart-drawer-overlay');

    if (navClient) navClient.style.display = staff ? 'none' : '';
    if (navStaff) navStaff.style.display = staff ? '' : 'none';
    if (actionsClient) actionsClient.style.display = staff ? 'none' : '';
    if (actionsStaff) actionsStaff.style.display = staff ? '' : 'none';
    if (footerLink) footerLink.style.display = staff ? 'none' : '';
    if (navbar) navbar.dataset.mode = staff ? 'staff' : 'client';

    // Customer account buttons (sign in vs. my account)
    const member = this.isUser();
    const signinBtn = document.getElementById('btn-signin');
    const accountBtn = document.getElementById('btn-myaccount');
    const nameLabel = document.getElementById('user-name-label');
    if (signinBtn) signinBtn.style.display = member ? 'none' : '';
    if (accountBtn) accountBtn.style.display = member ? '' : 'none';
    if (nameLabel) {
      const u = this.currentUser();
      nameLabel.textContent = u ? String(u.name).split(' ')[0] : '';
    }
    this.prefillForms();

    // Close cart if switching to staff
    if (staff && cartOverlay) cartOverlay.classList.remove('active');
  }
};

window.Auth = Auth;

document.addEventListener('DOMContentLoaded', () => {
  window.showToast = function(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <span>${type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span>
      <div>${message}</div>
    `;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  };

  const viewSections = document.querySelectorAll('.view-section');

  function setActiveNav(viewId) {
    document.querySelectorAll('.nav-link').forEach(link => {
      if (link.dataset.view === viewId) link.classList.add('active');
      else link.classList.remove('active');
    });
  }

  function navigateTo(viewId) {
    // Gate staff-only views
    if (STAFF_VIEWS.has(viewId) && !Auth.isStaff()) {
      viewId = 'login';
      if (window.showToast) window.showToast('Staff login required', 'error');
    }

    // Logged-in staff trying to open login → send to dashboard
    if (viewId === 'login' && Auth.isStaff()) {
      viewId = 'admin';
    }

    // Customer account pages
    if (viewId === 'account' && Auth.isUser()) viewId = 'myaccount';
    if (viewId === 'myaccount' && !Auth.isUser()) {
      viewId = 'account';
      if (window.showToast) window.showToast('Please sign in to see your account', 'info');
    }

    // If staff is on a client page via direct call, still allow (optional)
    // Keep client views available only in client chrome; staff can still be forced home on logout

    viewSections.forEach(section => section.classList.remove('active'));

    const targetSection = document.getElementById(`view-${viewId}`);
    if (targetSection) {
      targetSection.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    setActiveNav(viewId);

    if (viewId === 'menu' && typeof MenuController !== 'undefined') MenuController.init();
    if (viewId === 'account' && typeof AccountController !== 'undefined') AccountController.showTab('signin');
    if (viewId === 'myaccount' && typeof AccountController !== 'undefined') AccountController.load();
    Auth.prefillForms();
    if (viewId === 'reservation' && typeof ReservationController !== 'undefined') ReservationController.init();
    if (viewId === 'kds' && typeof KDSController !== 'undefined') KDSController.init();
    if (viewId === 'admin' && typeof AdminController !== 'undefined') AdminController.init();
    if (viewId === 'reviews' && typeof ReviewController !== 'undefined') ReviewController.init();
  }

  document.querySelectorAll('[data-view]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const viewId = link.dataset.view;
      if (viewId) navigateTo(viewId);
    });
  });

  // Staff login form
  const loginForm = document.getElementById('staff-login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const pw = document.getElementById('staff-password');
      const value = pw ? pw.value : '';
      const result = await Auth.login(value);
      if (result.ok) {
        if (pw) pw.value = '';
        if (window.showToast) window.showToast('Welcome to the staff portal', 'success');
        navigateTo('admin');
      } else {
        if (window.showToast) window.showToast(result.message || 'Incorrect password', 'error');
      }
    });
  }

  // Customer sign-in / register
  if (typeof AccountController !== 'undefined') AccountController.bindForms(navigateTo);

  // Cart drawer
  const cartBtn = document.getElementById('btn-open-cart');
  const cartOverlay = document.getElementById('cart-drawer-overlay');
  const cartCloseBtn = document.getElementById('btn-close-cart');

  if (cartBtn && cartOverlay) {
    cartBtn.addEventListener('click', () => {
      if (!Auth.isStaff()) cartOverlay.classList.add('active');
    });
  }
  if (cartCloseBtn && cartOverlay) {
    cartCloseBtn.addEventListener('click', () => cartOverlay.classList.remove('active'));
  }

  // Modal close
  const modalOverlay = document.getElementById('global-modal-overlay');
  const modalCloseBtn = document.getElementById('global-modal-close');
  if (modalCloseBtn && modalOverlay) {
    modalCloseBtn.addEventListener('click', () => modalOverlay.classList.remove('active'));
  }

  // Navbar scroll effect
  window.addEventListener('scroll', () => {
    const navbar = document.getElementById('main-navbar');
    if (navbar) {
      if (window.scrollY > 40) navbar.classList.add('scrolled');
      else navbar.classList.remove('scrolled');
    }
  });

  // Restore staff chrome if session still valid
  Auth.applyChrome();

  // Client modules
  if (typeof Cart !== 'undefined') Cart.init();
  if (typeof MenuController !== 'undefined') MenuController.init();
  if (typeof ReservationController !== 'undefined') ReservationController.init();

  // If already logged in as staff, open dashboard; else home
  if (Auth.isStaff()) {
    navigateTo('admin');
  }

  window.navigateToView = navigateTo;
});
