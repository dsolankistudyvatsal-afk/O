/* ==========================================================================
   VERDANT LUXE - Admin Management & Analytics Controller
   ========================================================================== */

const AdminController = {
  _eventsBound: false,

  async init() {
    await this.loadStats();
    await this.loadAdminMenu();
    await this.loadAdminReservations();
    this.bindEvents();
  },

  bindEvents() {
    if (this._eventsBound) return;
    this._eventsBound = true;

    const addDishForm = document.getElementById('admin-add-dish-form');
    if (addDishForm) {
      addDishForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await this.handleAddDish(e);
      });
    }
  },

  async loadStats() {
    const stats = await API.getAdminStats();

    const revEl = document.getElementById('stat-revenue');
    const orderEl = document.getElementById('stat-orders');
    const resEl = document.getElementById('stat-reservations');
    const occEl = document.getElementById('stat-occupancy');

    if (revEl) revEl.textContent = `$${stats.revenue}`;
    if (orderEl) orderEl.textContent = stats.orderCount;
    if (resEl) resEl.textContent = stats.reservationCount;
    if (occEl) occEl.textContent = stats.occupancyRate;
  },

  async loadAdminMenu() {
    const tableBody = document.getElementById('admin-menu-table-body');
    if (!tableBody) return;

    const items = await API.getMenuItems();

    tableBody.innerHTML = items.map(item => `
      <tr>
        <td>
          <img src="${esc(item.image)}" class="table-img-thumb" alt="${esc(item.name)}" onerror="this.src='https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80'">
        </td>
        <td><strong>${esc(item.name)}</strong></td>
        <td><span class="badge badge-gold">${esc(String(item.category || '').toUpperCase())}</span></td>
        <td style="font-weight: 700; color: var(--gold-light);">$${Number(item.price).toFixed(2)}</td>
        <td>${esc(item.calories)} kcal</td>
        <td>
          <div class="table-actions">
            <button class="btn btn-sm btn-outline" style="color: #f87171;" onclick="AdminController.deleteDish('${esc(item.id)}')">Delete</button>
          </div>
        </td>
      </tr>
    `).join('');
  },

  async loadAdminReservations() {
    const tableBody = document.getElementById('admin-res-table-body');
    if (!tableBody) return;

    const resList = await API.getReservations();

    tableBody.innerHTML = resList.map(res => `
      <tr>
        <td><strong style="color: var(--gold-light);">${esc(res.id)}</strong></td>
        <td>${esc(res.name)}</td>
        <td>${esc(res.date)} @ ${esc(res.time)}</td>
        <td>${esc(res.guests)} Guests</td>
        <td>Table ${esc(res.tableId)}${res.zone ? ' · ' + esc(res.zone) : ''}</td>
        <td><span class="badge badge-green">${esc(String(res.status || '').toUpperCase())}</span></td>
      </tr>
    `).join('');
  },

  async handleAddDish(e) {
    const name = document.getElementById('new-dish-name').value.trim();
    const category = document.getElementById('new-dish-category').value;
    const price = parseFloat(document.getElementById('new-dish-price').value);
    const calories = parseInt(document.getElementById('new-dish-calories').value, 10);
    const imageInput = document.getElementById('new-dish-image').value.trim();
    const description = document.getElementById('new-dish-desc').value.trim();

    if (!name || !(price > 0) || !(calories > 0) || !description) {
      if (window.showToast) window.showToast('Please fill name, price, calories, and description', 'error');
      return;
    }

    const image = imageInput || (DEFAULT_IMAGES && DEFAULT_IMAGES.squash_steak) ||
      'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80';

    const payload = {
      name,
      category,
      price,
      calories,
      image,
      description,
      dietary: ['100% Veg'],
      featured: false
    };

    try {
      await API.addMenuItem(payload);
      if (window.showToast) window.showToast(`New dish "${name}" added to Menu!`, 'success');
      e.target.reset();
      await this.loadAdminMenu();
      await this.loadStats();
      if (typeof MenuController !== 'undefined') MenuController.loadMenu();
    } catch (err) {
      if (window.showToast) window.showToast(err.message || 'Failed to add dish', 'error');
    }
  },

  async deleteDish(id) {
    if (confirm('Are you sure you want to delete this dish from the menu?')) {
      await API.deleteMenuItem(id);
      if (window.showToast) window.showToast('Dish deleted successfully', 'success');
      await this.loadAdminMenu();
      await this.loadStats();
      if (typeof MenuController !== 'undefined') MenuController.loadMenu();
    }
  }
};

window.AdminController = AdminController;
