/* ==========================================================================
   VERDANT LUXE - Menu Interface & Dish Detail Modal Controller
   ========================================================================== */

const MenuController = {
  activeCategory: 'all',
  searchQuery: '',
  allDishes: [],
  _eventsBound: false,

  async init() {
    this.bindEvents();
    await this.loadMenu();
  },

  bindEvents() {
    if (this._eventsBound) return;
    this._eventsBound = true;

    const searchInput = document.getElementById('menu-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.searchQuery = e.target.value;
        this.renderMenu();
      });
    }

    const tabContainer = document.getElementById('category-tabs-container');
    if (tabContainer) {
      tabContainer.addEventListener('click', (e) => {
        const btn = e.target.closest('.tab-btn');
        if (btn) {
          document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          this.activeCategory = btn.dataset.category || 'all';
          this.renderMenu();
        }
      });
    }
  },

  async loadMenu() {
    const grid = document.getElementById('menu-grid-container');
    if (grid) {
      grid.innerHTML = `<div style="grid-column: 1/-1; text-align: center; color: var(--gold-light); padding: 4rem;"><div class="font-serif">Preparing Culinary Selection...</div></div>`;
    }
    this.allDishes = await API.getMenuItems();
    this.renderMenu();
  },

  renderMenu() {
    const grid = document.getElementById('menu-grid-container');
    if (!grid) return;

    let filtered = this.allDishes;

    if (this.activeCategory !== 'all') {
      filtered = filtered.filter(d => d.category === this.activeCategory);
    }

    if (this.searchQuery.trim()) {
      const q = this.searchQuery.toLowerCase();
      filtered = filtered.filter(d =>
        d.name.toLowerCase().includes(q) ||
        d.description.toLowerCase().includes(q)
      );
    }

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 4rem 1rem;">
          <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">🍳</div>
          <h3>No dishes matched your criteria</h3>
          <p>Try searching for another dish or clearing filters.</p>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map(dish => `
      <div class="dish-card">
        <div class="dish-img-wrapper" onclick="MenuController.showDishModal('${esc(dish.id)}')" style="cursor: pointer;">
          <img src="${esc(dish.image)}" alt="${esc(dish.name)}" class="dish-img" onerror="this.src='https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80'">
          ${dish.featured ? `<span class="badge badge-gold dish-badge">★ Chef Signature</span>` : ''}
        </div>
        <div class="dish-body">
          <div class="dish-header">
            <h3 class="dish-name" onclick="MenuController.showDishModal('${esc(dish.id)}')" style="cursor: pointer;">${esc(dish.name)}</h3>
            <span class="dish-price">$${Number(dish.price).toFixed(2)}</span>
          </div>
          <p class="dish-desc">${esc(dish.description)}</p>
          <div class="dish-footer">
            <div class="dietary-tags">
              ${(dish.dietary || []).map(t => `<span class="dietary-tag">${esc(t)}</span>`).join('')}
              <span class="dietary-tag">${esc(dish.calories)} kcal</span>
            </div>
            <button class="add-cart-btn" onclick="Cart.addItemById('${esc(dish.id)}')">
              + Add to Order
            </button>
          </div>
        </div>
      </div>
    `).join('');
  },

  showDishModal(dishId) {
    const dish = this.allDishes.find(d => d.id === dishId);
    if (!dish) return;

    const modalOverlay = document.getElementById('global-modal-overlay');
    const modalBody = document.getElementById('global-modal-body');

    modalBody.innerHTML = `
      <div style="position: relative;">
        <img src="${esc(dish.image)}" alt="${esc(dish.name)}" style="width: 100%; height: 260px; object-fit: cover; border-radius: var(--radius-md); margin-bottom: 1.5rem;" onerror="this.src='https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80'">

        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
          <h2 class="font-serif text-gold-gradient" style="font-size: 1.8rem;">${esc(dish.name)}</h2>
          <span style="font-size: 1.6rem; font-weight: 700; font-family: var(--font-heading); color: var(--gold-light);">$${Number(dish.price).toFixed(2)}</span>
        </div>

        <div style="display: flex; gap: 0.5rem; margin-bottom: 1rem; flex-wrap: wrap;">
          ${(dish.dietary || []).map(t => `<span class="badge badge-gold">${esc(t)}</span>`).join('')}
          <span class="badge badge-blue">${esc(dish.calories)} Calories</span>
          <span class="badge badge-green">Fresh Organic</span>
        </div>

        <p style="color: var(--text-muted); font-size: 1.05rem; margin-bottom: 1.5rem; line-height: 1.6;">${esc(dish.description)}</p>

        <div style="border-top: 1px solid var(--border-light); padding-top: 1rem; margin-bottom: 1.5rem;">
          <h4 style="font-size: 0.9rem; text-transform: uppercase; color: var(--gold-primary); margin-bottom: 0.5rem;">Chef's Preparation Notes:</h4>
          <p style="font-size: 0.9rem; color: var(--text-muted);">Prepared fresh upon order with imported artisanal ingredients. Please notify server of severe allergies.</p>
        </div>

        <div style="display: flex; gap: 1rem;">
          <button class="btn btn-primary" style="flex: 1;" onclick="Cart.addItemById('${esc(dish.id)}'); document.getElementById('global-modal-overlay').classList.remove('active');">
            Add to Order ($${Number(dish.price).toFixed(2)})
          </button>
        </div>
      </div>
    `;

    modalOverlay.classList.add('active');
  }
};

window.MenuController = MenuController;
