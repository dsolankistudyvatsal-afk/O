/* ==========================================================================
   VERDANT LUXE - Kitchen Display System (KDS) Queue Controller
   ========================================================================== */

const KDSController = {
  orders: [],
  _pollTimer: null,

  async init() {
    await this.loadOrders();
    if (!this._pollTimer) {
      this._pollTimer = setInterval(() => this.loadOrders(), 10000);
    }
  },

  async loadOrders() {
    if (!Auth.isStaff()) return; // orders are staff-only on the server
    try {
      this.orders = await API.getOrders();
      this.renderColumns();
    } catch (err) {
      console.warn('KDS refresh failed:', err.message);
    }
  },

  renderColumns() {
    const newCol = document.getElementById('kds-col-new');
    const prepCol = document.getElementById('kds-col-prep');
    const readyCol = document.getElementById('kds-col-ready');
    const doneCol = document.getElementById('kds-col-done');

    if (!newCol) return;

    const newOrders = this.orders.filter(o => o.status === 'new');
    const prepOrders = this.orders.filter(o => o.status === 'prep');
    const readyOrders = this.orders.filter(o => o.status === 'ready');
    const doneOrders = this.orders.filter(o => o.status === 'done');

    const setCount = (id, n) => {
      const el = document.getElementById(id);
      if (el) el.textContent = n;
    };
    setCount('kds-count-new', newOrders.length);
    setCount('kds-count-prep', prepOrders.length);
    setCount('kds-count-ready', readyOrders.length);
    setCount('kds-count-done', doneOrders.length);

    newCol.innerHTML = this.renderTickets(newOrders, 'Start Cooking', 'prep', 'btn-primary');
    prepCol.innerHTML = this.renderTickets(prepOrders, 'Mark Ready', 'ready', 'btn-primary');
    readyCol.innerHTML = this.renderTickets(readyOrders, 'Served / Complete', 'done', 'btn-outline');
    doneCol.innerHTML = this.renderTickets(doneOrders, 'Archived', '', '');
  },

  renderTickets(ticketList, actionText, nextStatus, btnClass) {
    if (ticketList.length === 0) {
      return `<div style="text-align: center; color: var(--text-muted); padding: 2rem; font-size: 0.85rem;">No orders</div>`;
    }

    return ticketList.map(order => {
      const elapsedMins = Math.floor((Date.now() - (order.timestamp || Date.now())) / (1000 * 60));

      return `
        <div class="order-ticket">
          <div class="ticket-header">
            <span class="ticket-id">${esc(order.id)}</span>
            <span class="ticket-timer">${elapsedMins} mins ago</span>
          </div>
          <div class="ticket-type">👤 ${esc(order.customerName)} • 📍 ${esc(order.type)}</div>

          <ul class="ticket-items">
            ${(order.items || []).map(i => `
              <li class="ticket-item">
                <span><span class="ticket-item-qty">${esc(i.qty)}x</span> ${esc(i.name)}</span>
                <span>$${(Number(i.price) * Number(i.qty)).toFixed(2)}</span>
              </li>
            `).join('')}
          </ul>

          <div style="display: flex; justify-content: space-between; font-size: 0.85rem; font-weight: 700;">
            <span>Total Value:</span>
            <span style="color: var(--gold-light);">$${Number(order.total).toFixed(2)}</span>
          </div>

          ${nextStatus ? `
            <div class="ticket-actions">
              <button class="btn ${btnClass} ticket-btn" onclick="KDSController.advanceStatus('${esc(order.id)}', '${esc(nextStatus)}')">
                ${esc(actionText)} →
              </button>
            </div>
          ` : ''}
        </div>
      `;
    }).join('');
  },

  async advanceStatus(orderId, nextStatus) {
    try {
      await API.updateOrderStatus(orderId, nextStatus);
      if (window.showToast) {
        window.showToast(`Order ${orderId} updated to ${nextStatus.toUpperCase()}`, 'success');
      }
      await this.loadOrders();
    } catch (err) {
      if (window.showToast) window.showToast('Failed to update ticket status', 'error');
    }
  }
};

window.KDSController = KDSController;
