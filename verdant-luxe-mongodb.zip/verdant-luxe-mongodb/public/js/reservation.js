/* ==========================================================================
   VERDANT LUXE - Table Reservation & Seating Controller
   ========================================================================== */

const ReservationController = {
  selectedTableId: null,
  tables: [],
  _eventsBound: false,

  async init() {
    this.bindEvents();
    await this.loadTables();
  },

  bindEvents() {
    if (this._eventsBound) return;
    this._eventsBound = true;

    const form = document.getElementById('reservation-form');
    if (form) {
      const dateInput = document.getElementById('res-date');
      if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.value = today;
        dateInput.min = today;
      }

      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        await this.handleReservationSubmit(e);
      });
    }
  },

  async loadTables() {
    this.tables = await API.getTables();
    this.renderSeatingMap();
  },

  renderSeatingMap() {
    const grid = document.getElementById('seating-map-container');
    if (!grid) return;

    grid.innerHTML = this.tables.map(table => {
      const isSelected = this.selectedTableId === table.id;
      const isOccupied = table.status === 'occupied';

      return `
        <div class="table-node ${isOccupied ? 'occupied' : ''} ${isSelected ? 'selected' : ''}"
             onclick="${isOccupied ? '' : `ReservationController.selectTable('${esc(table.id)}')`}">
          <div class="table-status-pill"></div>
          <div class="table-icon">🪑</div>
          <div class="table-name">${esc(table.id)} (${esc(table.zone)})</div>
          <div class="table-capacity">${esc(table.capacity)} Guests</div>
        </div>
      `;
    }).join('');
  },

  selectTable(tableId) {
    this.selectedTableId = tableId;
    const table = this.tables.find(t => t.id === tableId);
    if (!table) return;

    const tableInput = document.getElementById('res-table-id');
    if (tableInput) tableInput.value = tableId;

    if (window.showToast) {
      window.showToast(`Selected Table ${table.id} (${table.zone} - ${table.capacity} seats)`, 'success');
    }

    this.renderSeatingMap();
  },

  async handleReservationSubmit(e) {
    const name = document.getElementById('res-name').value.trim();
    const email = document.getElementById('res-email').value.trim();
    const phone = document.getElementById('res-phone').value.trim();
    const date = document.getElementById('res-date').value;
    const time = document.getElementById('res-time').value;
    const guests = parseInt(document.getElementById('res-guests').value, 10);
    const tableId = document.getElementById('res-table-id').value || this.selectedTableId || 'T1';
    const notes = document.getElementById('res-notes').value.trim();

    const table = this.tables.find(t => t.id === tableId);
    const zone = table ? table.zone : '';

    if (!name || !email || !phone || !date || !time) {
      if (window.showToast) window.showToast('Please complete all required fields', 'error');
      return;
    }

    const payload = {
      name, email, phone, date, time, guests, tableId, zone, specialNotes: notes
    };

    try {
      const reservation = await API.createReservation(payload);

      if (window.showToast) {
        window.showToast(`Reservation ${reservation.id} confirmed! Digital pass generated.`, 'success');
      }

      this.showDigitalPassModal(reservation);
      e.target.reset();
      if (window.Auth) Auth.prefillForms();
      const dateInput = document.getElementById('res-date');
      if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.value = today;
        dateInput.min = today;
      }
      this.selectedTableId = null;
      this.renderSeatingMap();

    } catch (err) {
      if (window.showToast) window.showToast(err.message || 'Reservation failed. Try again.', 'error');
    }
  },

  showDigitalPassModal(res) {
    const modalOverlay = document.getElementById('global-modal-overlay');
    const modalBody = document.getElementById('global-modal-body');

    modalBody.innerHTML = `
      <div style="text-align: center;">
        <div style="font-size: 2.5rem; color: var(--gold-primary); margin-bottom: 0.5rem;">👑</div>
        <h2 class="font-serif text-gold-gradient" style="font-size: 1.8rem; margin-bottom: 0.2rem;">Table Reservation Confirmed</h2>
        <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1.5rem;">VERDANT LUXE Fine Dining Experience</p>

        <div style="background: var(--bg-card); border: 2px dashed var(--border-glass); border-radius: var(--radius-md); padding: 1.5rem; text-align: left; margin-bottom: 1.5rem;">
          <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-light); padding-bottom: 0.75rem; margin-bottom: 0.75rem;">
            <span>Pass Reference:</span>
            <strong style="color: var(--gold-light); font-family: monospace;">${esc(res.id)}</strong>
          </div>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; font-size: 0.95rem;">
            <div><strong>Guest Name:</strong><br><span style="color: var(--text-muted);">${esc(res.name)}</span></div>
            <div><strong>Party Size:</strong><br><span style="color: var(--text-muted);">${esc(res.guests)} Guests</span></div>
            <div><strong>Date & Time:</strong><br><span style="color: var(--text-muted);">${esc(res.date)} at ${esc(res.time)}</span></div>
            <div><strong>Assigned Table:</strong><br><span style="color: var(--gold-primary); font-weight: 700;">Table ${esc(res.tableId)}${res.zone ? ' · ' + esc(res.zone) : ''}</span></div>
          </div>
          ${res.specialNotes ? `
            <div style="margin-top: 0.75rem; border-top: 1px solid var(--border-light); padding-top: 0.5rem; font-size: 0.85rem; color: var(--text-muted);">
              <strong>Special Request:</strong> ${esc(res.specialNotes)}
            </div>
          ` : ''}
        </div>

        <button class="btn btn-primary" onclick="document.getElementById('global-modal-overlay').classList.remove('active');">
          Save Confirmation Pass
        </button>
      </div>
    `;

    modalOverlay.classList.add('active');
  }
};

window.ReservationController = ReservationController;
