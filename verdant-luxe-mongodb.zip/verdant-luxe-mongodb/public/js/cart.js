/* ==========================================================================
   VERDANT LUXE - Shopping Cart & Checkout Controller
   ========================================================================== */

const Cart = {
  items: [],
  discountPercent: 0,
  appliedPromo: '',

  init() {
    this.render();
  },

  async addItemById(id) {
    const menu = await API.getMenuItems();
    const dish = menu.find(d => d.id === id);
    if (!dish) {
      if (window.showToast) window.showToast('Dish not found', 'error');
      return;
    }
    this.addItem(dish);
  },

  addItem(dish) {
    const existing = this.items.find(i => i.id === dish.id);
    if (existing) {
      existing.qty++;
    } else {
      this.items.push({
        id: dish.id,
        name: dish.name,
        price: dish.price,
        image: dish.image,
        qty: 1
      });
    }
    this.updateBadge();
    this.render();
    if (window.showToast) {
      window.showToast(`Added "${dish.name}" to your order`, 'success');
    }
  },

  removeItem(id) {
    this.items = this.items.filter(i => i.id !== id);
    this.updateBadge();
    this.render();
  },

  updateQty(id, delta) {
    const item = this.items.find(i => i.id === id);
    if (item) {
      item.qty += delta;
      if (item.qty <= 0) {
        this.removeItem(id);
      } else {
        this.updateBadge();
        this.render();
      }
    }
  },

  applyPromo(code) {
    const clean = (code || '').trim().toUpperCase();
    if (clean === 'AURAGOLD' || clean === 'VERDANT15') {
      this.discountPercent = 15;
      this.appliedPromo = clean + ' (15% OFF)';
      if (window.showToast) window.showToast('VIP Promo applied! 15% discount', 'success');
    } else {
      this.discountPercent = 0;
      this.appliedPromo = '';
      if (window.showToast) window.showToast('Invalid promo code. Try "AURAGOLD" or "VERDANT15"', 'error');
    }
    this.render();
  },

  getSubtotal() {
    return this.items.reduce((sum, item) => sum + item.price * item.qty, 0);
  },

  getDiscountAmount() {
    return (this.getSubtotal() * this.discountPercent) / 100;
  },

  getTotal() {
    return this.getSubtotal() - this.getDiscountAmount();
  },

  updateBadge() {
    const totalCount = this.items.reduce((sum, item) => sum + item.qty, 0);
    const badgeEl = document.getElementById('cart-badge-count');
    if (badgeEl) {
      badgeEl.textContent = totalCount;
      badgeEl.style.display = totalCount > 0 ? 'flex' : 'none';
    }
  },

  render() {
    const container = document.getElementById('cart-items-list');
    if (!container) return;

    if (this.items.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; color: var(--text-muted); padding: 3rem 1rem;">
          <div style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;">🥗</div>
          <p>Your culinary order is empty.</p>
          <small>Explore our fine dining menu to add dishes.</small>
        </div>
      `;
    } else {
      container.innerHTML = this.items.map(item => `
        <div class="cart-item">
          <img src="${esc(item.image)}" alt="${esc(item.name)}" class="cart-item-img" onerror="this.src='https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80'">
          <div class="cart-item-info">
            <div class="cart-item-name">${esc(item.name)}</div>
            <div class="cart-item-price">$${(item.price * item.qty).toFixed(2)}</div>
          </div>
          <div class="qty-controls">
            <button class="qty-btn" onclick="Cart.updateQty('${esc(item.id)}', -1)">-</button>
            <span style="font-weight: 600; font-size: 0.9rem; min-width: 18px; text-align: center;">${item.qty}</span>
            <button class="qty-btn" onclick="Cart.updateQty('${esc(item.id)}', 1)">+</button>
          </div>
        </div>
      `).join('');
    }

    const subtotalEl = document.getElementById('cart-subtotal');
    const discountEl = document.getElementById('cart-discount');
    const totalEl = document.getElementById('cart-total');

    if (subtotalEl) subtotalEl.textContent = `$${this.getSubtotal().toFixed(2)}`;
    if (discountEl) discountEl.textContent = `-$${this.getDiscountAmount().toFixed(2)}`;
    if (totalEl) totalEl.textContent = `$${this.getTotal().toFixed(2)}`;
  },

  async processCheckout(customerDetails) {
    if (this.items.length === 0) {
      if (window.showToast) window.showToast('Your order is empty', 'error');
      return;
    }

    const nameInput = document.getElementById('checkout-name');
    const typeInput = document.querySelector('input[name="checkout-type"]:checked');
    const customerName = (nameInput && nameInput.value.trim()) || (customerDetails && customerDetails.name) || 'Valued Guest';
    const orderType = (typeInput && typeInput.value) || (customerDetails && customerDetails.orderType) || 'Dine-In';

    const orderPayload = {
      customerName,
      type: orderType,
      items: this.items.map(i => ({ id: i.id, name: i.name, qty: i.qty, price: i.price })),
      promoCode: (this.appliedPromo || '').split(' ')[0], // server re-validates & recomputes the total
      total: this.getTotal() // informational only; server recalculates from menu prices
    };

    try {
      const createdOrder = await API.createOrder(orderPayload);
      this.items = [];
      this.discountPercent = 0;
      this.appliedPromo = '';
      this.updateBadge();
      this.render();

      const overlay = document.getElementById('cart-drawer-overlay');
      if (overlay) overlay.classList.remove('active');

      if (window.showToast) {
        window.showToast(`Order ${createdOrder.id} successfully placed! Sent to Kitchen KDS.`, 'success');
      }

      this.showOrderTrackerModal(createdOrder);

      if (typeof KDSController !== 'undefined') KDSController.loadOrders();

    } catch (err) {
      if (window.showToast) window.showToast(err.message || 'Checkout failed. Try again.', 'error');
    }
  },

  showOrderTrackerModal(order) {
    const modalOverlay = document.getElementById('global-modal-overlay');
    const modalBody = document.getElementById('global-modal-body');

    modalBody.innerHTML = `
      <div style="text-align: center;">
        <div style="font-size: 2.5rem; color: var(--gold-primary); margin-bottom: 0.5rem;">🎉</div>
        <h2 style="font-size: 1.8rem; margin-bottom: 0.5rem;" class="font-serif text-gold-gradient">Order Confirmed!</h2>
        <p style="color: var(--text-muted); margin-bottom: 1.5rem;">Ticket ID: <strong>${esc(order.id)}</strong></p>

        <div class="order-tracker">
          <div style="display: flex; justify-content: space-between; font-size: 0.9rem;">
            <span>Customer: <strong>${esc(order.customerName)}</strong></span>
            <span>Type: <strong>${esc(order.type)}</strong></span>
          </div>
          <div class="tracker-steps">
            <div class="tracker-step completed">
              <div class="step-icon">✓</div>
              <div class="step-label">Received</div>
            </div>
            <div class="tracker-step active">
              <div class="step-icon">🔥</div>
              <div class="step-label">Kitchen Prep</div>
            </div>
            <div class="tracker-step">
              <div class="step-icon">🍽️</div>
              <div class="step-label">Plating</div>
            </div>
            <div class="tracker-step">
              <div class="step-icon">⭐</div>
              <div class="step-label">Serving</div>
            </div>
          </div>
        </div>

        <div style="margin-top: 1.5rem;">
          <button class="btn btn-primary" onclick="document.getElementById('global-modal-overlay').classList.remove('active');">Done</button>
        </div>
      </div>
    `;

    modalOverlay.classList.add('active');
  }
};

window.Cart = Cart;
