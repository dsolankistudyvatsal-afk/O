/* ==========================================================================
   VERDANT LUXE - Customer account: sign in / register / order history
   ========================================================================== */

const ORDER_STATUS_LABELS = {
  new: 'Received',
  prep: 'Preparing',
  ready: 'Ready',
  done: 'Completed',
  cancelled: 'Cancelled'
};

const AccountController = {
  _bound: false,

  /** Wire up the sign-in / register forms (called once from app.js) */
  bindForms(navigateTo) {
    if (this._bound) return;
    this._bound = true;

    const loginForm = document.getElementById('user-login-form');
    const registerForm = document.getElementById('user-register-form');

    document.querySelectorAll('[data-auth-tab]').forEach((tab) => {
      tab.addEventListener('click', () => this.showTab(tab.dataset.authTab));
    });

    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value.trim();
        const password = document.getElementById('login-password').value;
        const result = await Auth.userLogin(email, password);
        if (result.ok) {
          loginForm.reset();
          if (window.showToast) window.showToast('Welcome back!', 'success');
          navigateTo('myaccount');
        } else if (window.showToast) {
          window.showToast(result.message || 'Sign in failed', 'error');
        }
      });
    }

    if (registerForm) {
      registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('register-name').value.trim();
        const email = document.getElementById('register-email').value.trim();
        const password = document.getElementById('register-password').value;
        const confirm = document.getElementById('register-confirm').value;

        if (password !== confirm) {
          if (window.showToast) window.showToast('Passwords do not match', 'error');
          return;
        }
        const result = await Auth.register(name, email, password);
        if (result.ok) {
          registerForm.reset();
          if (window.showToast) window.showToast('Account created — welcome to Verdant Luxe!', 'success');
          navigateTo('myaccount');
        } else if (window.showToast) {
          window.showToast(result.message || 'Could not create account', 'error');
        }
      });
    }
  },

  showTab(which) {
    const signin = which === 'signin';
    const loginForm = document.getElementById('user-login-form');
    const registerForm = document.getElementById('user-register-form');
    if (loginForm) loginForm.style.display = signin ? '' : 'none';
    if (registerForm) registerForm.style.display = signin ? 'none' : '';
    document.getElementById('tab-signin').classList.toggle('active', signin);
    document.getElementById('tab-register').classList.toggle('active', !signin);
  },

  async load() {
    const user = Auth.currentUser();
    if (!user) return;
    document.getElementById('account-name').textContent = user.name;
    document.getElementById('account-email').textContent = user.email;

    const ordersEl = document.getElementById('account-orders');
    const resEl = document.getElementById('account-reservations');
    ordersEl.innerHTML = '<div class="account-empty">Loading…</div>';
    resEl.innerHTML = '<div class="account-empty">Loading…</div>';

    try {
      const [orders, reservations] = await Promise.all([
        API.getMyOrders(),
        API.getMyReservations()
      ]);
      this.renderOrders(ordersEl, orders);
      this.renderReservations(resEl, reservations);
    } catch (err) {
      // 401 is handled by Auth.expireUser(); anything else gets a message
      if (err.status !== 401) {
        ordersEl.innerHTML = `<div class="account-empty">${esc(err.message)}</div>`;
        resEl.innerHTML = '';
      }
    }
  },

  renderOrders(el, orders) {
    if (!orders.length) {
      el.innerHTML = '<div class="account-empty">No orders yet — they will appear here after you check out while signed in.</div>';
      return;
    }
    el.innerHTML = orders.map((o) => {
      const when = o.timestamp ? new Date(o.timestamp).toLocaleString() : '';
      const items = (o.items || []).map((i) => `${esc(i.qty)}× ${esc(i.name)}`).join(', ');
      return `
        <div class="glass-panel account-card">
          <div class="account-card-top">
            <span class="account-card-id">${esc(o.id)}</span>
            <span class="badge badge-green">${esc(ORDER_STATUS_LABELS[o.status] || o.status)}</span>
          </div>
          <div class="account-card-meta">${esc(when)} · ${esc(o.type)}</div>
          <div class="account-card-items">${items}</div>
          <div class="account-card-total">$${Number(o.total || 0).toFixed(2)}</div>
        </div>`;
    }).join('');
  },

  renderReservations(el, list) {
    if (!list.length) {
      el.innerHTML = '<div class="account-empty">No reservations yet — book a table while signed in and it will show up here.</div>';
      return;
    }
    el.innerHTML = list.map((r) => `
      <div class="glass-panel account-card">
        <div class="account-card-top">
          <span class="account-card-id">${esc(r.id)}</span>
          <span class="badge badge-green">${esc(String(r.status || '').toUpperCase())}</span>
        </div>
        <div class="account-card-meta">${esc(r.date)} @ ${esc(r.time)} · ${esc(r.guests)} guests</div>
        <div class="account-card-items">${r.tableId ? 'Table ' + esc(r.tableId) : ''}${r.zone ? ' · ' + esc(r.zone) : ''}</div>
        ${r.specialNotes ? `<div class="account-card-meta">${esc(r.specialNotes)}</div>` : ''}
      </div>`).join('');
  }
};

window.AccountController = AccountController;
