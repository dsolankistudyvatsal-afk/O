/* ==========================================================================
   VERDANT LUXE - REST API client (talks to the Express + MongoDB backend)
   ========================================================================== */

const API_BASE = window.API_BASE || '/api';
const TOKEN_KEY = 'vl_staff_token';       // staff session (sessionStorage)
const USER_TOKEN_KEY = 'vl_user_token';   // customer session (localStorage)

// High-resolution Pure Vegetarian & Gourmet Botanical Food Visuals
const DEFAULT_IMAGES = {
  hero: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=1600&q=80',
  risotto: 'https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?auto=format&fit=crop&w=800&q=80',
  squash_steak: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
  pasta: 'https://images.unsplash.com/photo-1621996346565-e3d5d6281270?auto=format&fit=crop&w=800&q=80',
  oyster_scallops: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
  beetroot: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=800&q=80',
  arancini: 'https://images.unsplash.com/photo-1541529086526-db283c563270?auto=format&fit=crop&w=800&q=80',
  avocado_tartare: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=800&q=80',
  artichoke: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
  chocolate: 'https://images.unsplash.com/photo-1579372786545-d24232daf58c?auto=format&fit=crop&w=800&q=80',
  souffle: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=800&q=80',
  cocktail1: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=800&q=80',
  cocktail2: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80'
};

// Escape user text before injecting into HTML
function esc(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function getToken() {
  try { return sessionStorage.getItem(TOKEN_KEY); } catch (e) { return null; }
}

function getUserToken() {
  try { return localStorage.getItem(USER_TOKEN_KEY); } catch (e) { return null; }
}

/** Single place that talks to the server. Throws Error(message) on non-2xx. */
// auth: true  -> send the staff token;  user: true -> send the customer token (if any)
async function request(path, { method = 'GET', body, auth = false, user = false, query } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';

  const kind = auth ? 'staff' : user ? 'user' : null;
  const token = kind === 'staff' ? getToken() : kind === 'user' ? getUserToken() : null;
  if (token) headers['Authorization'] = 'Bearer ' + token;

  let url = API_BASE + path;
  if (query) {
    const qs = new URLSearchParams(
      Object.entries(query).filter(([, v]) => v !== undefined && v !== null && v !== '')
    ).toString();
    if (qs) url += '?' + qs;
  }

  let res;
  try {
    res = await fetch(url, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
  } catch (e) {
    throw new Error('Cannot reach the server. Is it running?');
  }

  let data = null;
  try { data = await res.json(); } catch (e) { /* empty body */ }

  if (!res.ok) {
    // Expired / invalid session: sign out
    if (res.status === 401 && token && window.Auth) {
      if (kind === 'staff' && typeof Auth.expireSession === 'function') Auth.expireSession();
      if (kind === 'user' && typeof Auth.expireUser === 'function') Auth.expireUser();
    }
    const err = new Error((data && data.error) || 'Request failed (' + res.status + ')');
    err.status = res.status;
    throw err;
  }
  return data;
}

const API = {
  // ---- Customer accounts ----
  register(name, email, password) {
    return request('/auth/register', { method: 'POST', body: { name, email, password } }); // -> { token, user }
  },
  userLogin(email, password) {
    return request('/auth/user-login', { method: 'POST', body: { email, password } });      // -> { token, user }
  },
  getMe() {
    return request('/auth/me', { user: true });
  },
  getMyOrders() {
    return request('/orders/mine', { user: true });
  },
  getMyReservations() {
    return request('/reservations/mine', { user: true });
  },

  // ---- Staff auth ----
  async login(password) {
    const { token } = await request('/auth/login', { method: 'POST', body: { password } });
    return token;
  },

  // ---- Menu ----
  getMenuItems(category = 'all', searchQuery = '') {
    return request('/menu', { query: { category: category !== 'all' ? category : '', q: searchQuery } });
  },
  addMenuItem(dishData) {
    return request('/menu', { method: 'POST', body: dishData, auth: true });
  },
  deleteMenuItem(id) {
    return request('/menu/' + encodeURIComponent(id), { method: 'DELETE', auth: true });
  },

  // ---- Orders ----
  getOrders() {
    return request('/orders', { auth: true });
  },
  createOrder(orderPayload) {
    return request('/orders', { method: 'POST', body: orderPayload, user: true });
  },
  updateOrderStatus(orderId, newStatus) {
    return request('/orders/' + encodeURIComponent(orderId) + '/status', {
      method: 'PATCH', body: { status: newStatus }, auth: true
    });
  },

  // ---- Tables & reservations ----
  getTables() {
    return request('/tables');
  },
  getReservations() {
    return request('/reservations', { auth: true });
  },
  createReservation(resPayload) {
    return request('/reservations', { method: 'POST', body: resPayload, user: true });
  },

  // ---- Reviews ----
  getReviews() {
    return request('/reviews');
  },
  addReview(reviewData) {
    return request('/reviews', { method: 'POST', body: reviewData });
  },

  // ---- Admin ----
  getAdminStats() {
    return request('/admin/stats', { auth: true });
  }
};

// Expose globals for classic-script cross-file access
window.API = API;
window.DEFAULT_IMAGES = DEFAULT_IMAGES;
window.esc = esc;
