/* ==========================================================================
   VERDANT LUXE - Customer Review Engine
   ========================================================================== */

const ReviewController = {
  reviews: [],
  _eventsBound: false,

  async init() {
    this.bindEvents();
    await this.loadReviews();
  },

  bindEvents() {
    if (this._eventsBound) return;
    this._eventsBound = true;

    const form = document.getElementById('review-form');
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        await this.handleSubmitReview(e);
      });
    }
  },

  async loadReviews() {
    this.reviews = await API.getReviews();
    this.renderReviews();
  },

  renderReviews() {
    const container = document.getElementById('reviews-grid-container');
    if (!container) return;

    if (!this.reviews.length) {
      container.innerHTML = `<p style="color: var(--text-muted);">No reviews yet. Be the first!</p>`;
      return;
    }

    container.innerHTML = this.reviews.map(rev => `
      <div style="background: var(--bg-card); border: 1px solid var(--border-light); padding: 1.5rem; border-radius: var(--radius-md); display: flex; flex-direction: column; gap: 0.75rem;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <strong style="font-size: 1.1rem; color: var(--gold-light);">${esc(rev.author)}</strong>
          <span style="color: #f59e0b; font-size: 1.1rem;">${'★'.repeat(Math.min(5, Math.max(1, Number(rev.rating) || 5)))}</span>
        </div>
        <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6; flex: 1;">"${esc(rev.comment)}"</p>
        <span style="font-size: 0.75rem; color: var(--text-muted); text-align: right;">Verified Diner • ${esc(rev.date)}</span>
      </div>
    `).join('');
  },

  async handleSubmitReview(e) {
    const author = document.getElementById('review-author').value.trim();
    const rating = parseInt(document.getElementById('review-rating').value, 10);
    const comment = document.getElementById('review-comment').value.trim();

    if (!author || !comment || !(rating >= 1 && rating <= 5)) {
      if (window.showToast) window.showToast('Please complete name, rating, and comment', 'error');
      return;
    }

    try {
      await API.addReview({ author, rating, comment });
      if (window.showToast) window.showToast('Thank you! Your dining review was submitted.', 'success');
      e.target.reset();
      await this.loadReviews();
    } catch (err) {
      if (window.showToast) window.showToast('Failed to submit review', 'error');
    }
  }
};

window.ReviewController = ReviewController;
